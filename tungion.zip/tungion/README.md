# TUNGION · The Daily Dive

7 prompts · 15 seconds each · rarer answers sink deeper.

A daily trivia game where obvious answers barely count. Every prompt has a chart of
accepted answers sorted into six tiers; the rarer your answer, the deeper your krill sinks.
Every point is 10 m, and a perfect dive (700 pts) reaches 7,000 m.

| Tier | Points | Depth |
|---|---|---|
| Plankton | 10 | 100 m |
| Too Clever | 15 | 150 m |
| Schooler | 30 | 300 m |
| Rare | 60 | 600 m |
| Deep Cut | 85 | 850 m |
| One in a Tungion | 100 | 1,000 m |

Modes: **Daily Dive** (one per day, same 7 prompts for everyone, resets at local midnight),
**Themed Packs** (7 prompts from one theme, replayable) and **Unlimited** (one 45-second
air tank that drains only while you're answering).

## Run it in GitHub Codespaces

1. Create a new GitHub repository and upload every file in this folder
   (keep the hidden `.devcontainer` folder).
2. On the repo page click **Code → Codespaces → Create codespace on main**.
3. When the codespace opens, the game server starts on its own and the
   game opens in a new browser tab. If the tab doesn't appear, open the
   **Ports** panel and click the globe icon next to port **8080**.

If the server isn't running for any reason, type this in the terminal:

```
python3 -m http.server 8080
```

## Run it anywhere else

It's a static site with no build step: open `index.html` in a browser, or serve the
folder with any static server.

## Editing the game

- `data.js` – all prompts and answer charts. Commas separate answers, `|` separates
  aliases of the same answer. Add a prompt object to add a new prompt.
- `game.js` – game logic and the pixel-art ocean. Timer length, air tank and launch date
  are at the top.
- `style.css` – look and feel.
